// Copyright (c) 2024 Files Community
// Licensed under the MIT License. See the LICENSE.

// Note:
//  Including SDKDDKVer.h defines the latest Windows platform available.
//  If you want to compile the application for an older Windows platform, include WinSDKVer.h and
//  set the _WIN32_WINNT macro to the platform to support before including SDKDDKVer.h.

#pragma once

#include <SDKDDKVer.h>
